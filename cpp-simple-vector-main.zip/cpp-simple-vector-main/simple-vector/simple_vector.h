#pragma once

#include <cassert>
#include <stdexcept>
#include <utility>
#include <initializer_list>

#include "array_ptr.h"

class ReserveProxyObj {
public:
    ReserveProxyObj(size_t capacity)
        : capacity_(capacity)
    {
    }

    size_t GetCapacity() {
        return capacity_;
    }

private:
    size_t capacity_;
};

ReserveProxyObj Reserve(size_t capacity_to_reserve) {
    return ReserveProxyObj(capacity_to_reserve);
};

template <typename Type>
class SimpleVector {
    ArrayPtr<Type> data{ nullptr };
    size_t size{ 0 };
    size_t capasity{ 0 };
public:
    using Iterator = Type*;
    using ConstIterator = const Type*;

    SimpleVector() noexcept = default;

    // Создаёт вектор из size элементов, инициализированных значением по умолчанию
    explicit SimpleVector(size_t size) : SimpleVector(size, Type{}) {
        // Напишите тело конструктора самостоятельно
    }

    // Создаёт вектор из size элементов, инициализированных значением value
    SimpleVector(size_t size, const Type& value) :
        data(size),
        size(size),
        capasity(size)
    {
        // Напишите тело конструктора самостоятельно
        std::fill(data.Get(), data.Get() + size, value);
    }

    // Создаёт вектор из std::initializer_list
    SimpleVector(std::initializer_list<Type> init) :
        data{ init.size() },
        size{ init.size() },
        capasity{ init.size() }
    {
        // Напишите тело конструктора самостоятельно
        std::copy(init.begin(), init.end(), data.Get());
    }

    SimpleVector(const SimpleVector& other) :
        data{ new Type[other.capasity] },
        size{ other.size },
        capasity{ other.capasity }
    {
        // Напишите тело конструктора самостоятельно
        std::copy(other.begin(), other.end(), data.Get());
    }

    SimpleVector(SimpleVector&& other) :
        data{ other.capasity },
        size{ other.size },
        capasity{ other.capasity }
    {
        // Напишите тело конструктора самостоятельно
        std::move(other.begin(), other.end(), data.Get());
        other.size = 0;
    }

    explicit SimpleVector(ReserveProxyObj obj)
    {
        Reserve(obj.GetCapacity());
    }

    SimpleVector operator= (const SimpleVector& other) {
        // Напишите тело конструктора самостоятельно
        if (this == &other)
            return *this;

        Type* new_data{ new Type[other.capasity] };
        std::copy(other.begin(), other.end(), new_data);
        size = other.size;
        capasity = other.capasity;

        delete[] data.Release();
        data.Set(new_data);
        return *this;
    }

    SimpleVector operator= (SimpleVector&& other) {
        // Напишите тело конструктора самостоятельно
        if (this == &other)
            return *this;

        Type* new_data{ new Type[other.capasity] };
        std::move(other.begin(), other.end(), new_data);
        size = other.size;
        capasity = other.capasity;

        delete[] data.Release();
        data.Set(new_data);
        return *this;
    }

    // Добавляет элемент в конец вектора
    // При нехватке места увеличивает вдвое вместимость вектора

    void PushBack(const Type& value) {
        // Напишите тело самостоятельно
        if (0 == capasity) {
            data = new Type[++capasity];
        } else if (size == capasity) {
            Type* new_data = new Type[capasity <<= 1];
            std::move(data, data + size, new_data);
            std::swap(data, new_data);
            delete[] new_data;
        }
        data[size] = value;
        ++size;
    }

    void PushBack(Type&& value) {
        // Напишите тело самостоятельно
        if (0 == capasity) {
            data.Set(new Type[++capasity]);
        } else if (size == capasity) {
            Type* new_data = new Type[capasity <<= 1];
            std::move(data.Get(), data.Get() + size, new_data);
            delete[] data.Release();
            data.Set(new_data);
        }
        data[size] = std::move(value);
        ++size;
    }

    // Вставляет значение value в позицию pos.
    // Возвращает итератор на вставленное значение
    // Если перед вставкой значения вектор был заполнен полностью,
    // вместимость вектора должна увеличиться вдвое, а для вектора вместимостью 0 стать равной 1
    Iterator Insert(ConstIterator pos, const Type& value) {
        // Напишите тело самостоятельно
        assert(pos >= begin() && pos <= end());

        if (0 == capasity) {
            return data = new Type[capasity = ++size]{ value };
        }

        Type* new_data{ data };

        if (capasity == size) {
            new_data = new Type[capasity <<= 1];
            std::copy(data, pos, new_data);
        }

        if (end() != pos) {
            std::move(pos + 1, data + size, new_data);
        }

        auto new_pos{ pos - data };
        new_data[new_pos] = std::move(value);
        std::swap(data, new_data);
        if (data != new_data)
            delete[] new_data;
        ++size;

        return &data[new_pos];
    }

    Iterator Insert(Iterator pos, Type&& value) {
        // Напишите тело самостоятельно
        assert(pos >= begin() && pos <= end());

        if (0 == capasity) {
            return data.Set(new Type[capasity = ++size]{ std::move(value) });
        }

        Type* new_data{ data.Get() };

        if (capasity == size) {
            new_data = new Type[capasity <<= 1];
            std::move(data.Get(), pos, new_data);
        }

        if (end() != pos) {
            std::move(pos + 1, data.Get() + size, new_data);
        }

        auto new_pos{ pos - data.Get() };
        new_data[new_pos] = std::move(value);

        if (data.Get() != new_data) {
            delete[] data.Release();
            data.Set(new_data);   
        }
        ++size;

        return &data[new_pos];
    }
    // "Удаляет" последний элемент вектора. Вектор не должен быть пустым
    void PopBack() noexcept {
        // Напишите тело самостоятельно
        if (size)
            --size;
    }

    // Удаляет элемент вектора в указанной позиции
    Iterator Erase(ConstIterator pos) {
        // Напишите тело самостоятельно
        assert(pos >= begin() && pos < end());
        size_t diff{ static_cast<size_t>(pos - data.Get()) };
        std::move(data.Get() + diff + 1, data.Get() + size, data.Get() + diff);
        --size;
        return &data[diff];
    }

    // Обменивает значение с другим вектором
    void swap(SimpleVector& other) noexcept {
        // Напишите тело самостоятельно
        data.swap(other.data);
        std::swap(size, other.size);
        std::swap(capasity, other.capasity);
    }

    // Возвращает количество элементов в массиве
    size_t GetSize() const noexcept {
        // Напишите тело самостоятельно
        return size;
    }

    // Возвращает вместимость массива
    size_t GetCapacity() const noexcept {
        // Напишите тело самостоятельно
        return capasity;
    }

    // Сообщает, пустой ли массив
    bool IsEmpty() const noexcept {
        return !size;
    }

    // Возвращает ссылку на элемент с индексом index
    Type& operator[](size_t index) noexcept {
        // Напишите тело самостоятельно
        assert(index < size);
        return data[index];
    }

    // Возвращает константную ссылку на элемент с индексом index
    const Type& operator[](size_t index) const noexcept {
        // Напишите тело самостоятельно
        assert(index < size);
        return data[index];
    }

    // Возвращает константную ссылку на элемент с индексом index
    // Выбрасывает исключение std::out_of_range, если index >= size
    Type& At(size_t index) {
        // Напишите тело самостоятельно
        if (index >= size)
            throw std::out_of_range{"out_of_range"};
        return data[index];
    }

    // Возвращает константную ссылку на элемент с индексом index
    // Выбрасывает исключение std::out_of_range, если index >= size
    const Type& At(size_t index) const {
        // Напишите тело самостоятельно
        if (index >= size)
            throw std::out_of_range{ "out_of_range" };
        return data[index];
    }

    // Обнуляет размер массива, не изменяя его вместимость
    void Clear() noexcept {
        // Напишите тело самостоятельно
        size = 0;
    }

    // Изменяет размер массива.
    // При увеличении размера новые элементы получают значение по умолчанию для типа Type
    void Resize(size_t new_size) {
        // Напишите тело самостоятельно
        if (capasity < new_size) {
            size_t new_capasity{ std::max(new_size, capasity << 1) };
            Type* new_data{ new Type[new_capasity] };
            std::move(data.Get(), data.Get() + size, new_data);
            delete[] data.Release();
            data.Set(new_data);
            capasity = new_capasity;
        }
        if (size < new_size) {
            for (size_t index = size; index < new_size; ++index) {
                data[index] = Type{};
            }
        }
        size = new_size;
    }

    void Reserve(size_t new_capacity) {
        if (new_capacity > capasity) {
            Type* new_data{ new Type[new_capacity]};
            std::copy(data.Get(), data.Get() + size, new_data);
            delete[] data.Release();
            data.Set(new_data);
            capasity = new_capacity;
        }
    };

    // Возвращает итератор на начало массива
    // Для пустого массива может быть равен (или не равен) nullptr
    Iterator begin() noexcept {
        // Напишите тело самостоятельно
        return data.Get();
    }

    // Возвращает итератор на элемент, следующий за последним
    // Для пустого массива может быть равен (или не равен) nullptr
    Iterator end() noexcept {
        // Напишите тело самостоятельно
        return data.Get() + size;
    }

    // Возвращает константный итератор на начало массива
    // Для пустого массива может быть равен (или не равен) nullptr
    ConstIterator begin() const noexcept {
        // Напишите тело самостоятельно
        return data.Get();
    }

    // Возвращает итератор на элемент, следующий за последним
    // Для пустого массива может быть равен (или не равен) nullptr
    ConstIterator end() const noexcept {
        // Напишите тело самостоятельно
        return data.Get() + size;
    }

    // Возвращает константный итератор на начало массива
    // Для пустого массива может быть равен (или не равен) nullptr
    ConstIterator cbegin() const noexcept {
        // Напишите тело самостоятельно
        return begin();
    }

    // Возвращает итератор на элемент, следующий за последним
    // Для пустого массива может быть равен (или не равен) nullptr
    ConstIterator cend() const noexcept {
        // Напишите тело самостоятельно
        return end();
    }
private:
    void Fill(Iterator front, Iterator back) {
        ;
    }
};

template <typename Type>
inline bool operator==(const SimpleVector<Type>& lhs, const SimpleVector<Type>& rhs) {
    // Заглушка. Напишите тело самостоятельно
    if (lhs.GetSize() != rhs.GetSize())
        return false;
    for (size_t index = 0, end = lhs.GetSize(); index < end; ++index) {
        if (lhs[index] != rhs[index])
            return false;
    }
    return true;
}

template <typename Type>
inline bool operator!=(const SimpleVector<Type>& lhs, const SimpleVector<Type>& rhs) {
    // Заглушка. Напишите тело самостоятельно
    return !(lhs == rhs);
}

template <typename Type>
inline bool operator<(const SimpleVector<Type>& lhs, const SimpleVector<Type>& rhs) {
    // Заглушка. Напишите тело самостоятельно
    return std::lexicographical_compare(lhs.begin(), lhs.end(),
        rhs.begin(), rhs.end());
}

template <typename Type>
inline bool operator<=(const SimpleVector<Type>& lhs, const SimpleVector<Type>& rhs) {
    // Заглушка. Напишите тело самостоятельно
    return !(lhs > rhs);
}

template <typename Type>
inline bool operator>(const SimpleVector<Type>& lhs, const SimpleVector<Type>& rhs) {
    // Заглушка. Напишите тело самостоятельно
    return std::lexicographical_compare(rhs.begin(), rhs.end(),
        lhs.begin(), lhs.end());
}

template <typename Type>
inline bool operator>=(const SimpleVector<Type>& lhs, const SimpleVector<Type>& rhs) {
    // Заглушка. Напишите тело самостоятельно
    return !(lhs < rhs);
}
