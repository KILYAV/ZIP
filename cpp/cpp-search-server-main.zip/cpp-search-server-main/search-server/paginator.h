#pragma once
#include <vector>
#include <iostream>

template<typename iterator>
class IteratorRange {
    iterator begin_, end_;
    size_t size_;
public:
    IteratorRange(iterator begin, iterator end) :
        begin_(begin),
        end_(end),
        size_(distance(begin, end)) {}
    auto begin() const {
        return begin_;
    }
    auto end() const {
        return end_;
    }
    auto size() const {
        return size;
    }
};

template<typename iterator>
class Paginator {
    std::vector<IteratorRange<iterator>> pages_{};
public:
    Paginator(iterator begin, iterator end, size_t page_size) {
        size_t size = distance(begin, end);
        size_t count_pages = size / page_size;
        for (size_t current = 0; current < count_pages; ++current) {
            auto end_page = next(begin, page_size);
            pages_.push_back({begin, end_page});
            begin = end_page;
        }
        if (auto remainder = size % page_size; 0 != remainder)
            pages_.push_back({begin, end});
    }
    auto begin() const {
        return pages_.begin();
    }
    auto end() const {
        return pages_.end();
    }
    auto size() const {
        return pages_.size();
    }
};

template <typename Container>
auto Paginate(const Container& c, size_t page_size) {
    return Paginator(std::begin(c), std::end(c), page_size);
};

template <typename iterator>
std::ostream& operator<<(std::ostream& out, const IteratorRange<iterator>& range) {
    for (auto iter = range.begin(); iter != range.end(); ++iter) {
        out << *iter;
    }
    return out;
}

std::ostream& operator<<(std::ostream& out, const Document& document) {
    out << "{ "s
        << "document_id = "s << document.id << ", "s
        << "relevance = "s << document.relevance << ", "s
        << "rating = "s << document.rating << " }"s;
    return out;
}