#pragma once
#include <vector>
#include <string>
#include <stdexcept>

std::vector<std::string> SplitIntoWords(const std::string&);