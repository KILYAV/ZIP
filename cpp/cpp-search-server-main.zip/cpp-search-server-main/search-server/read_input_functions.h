#pragma once
#include <set>
#include <vector>
#include <string>
#include <iostream>
#include <algorithm>

std::string ReadLine();

int ReadLineWithNumber();

std::vector<std::string> SplitIntoWords(const std::string& text);

template <typename StringContainer>
std::set<std::string> MakeUniqueNonEmptyStrings(const StringContainer& strings) {
    std::set<std::string> non_empty_strings;
    for (const std::string& str : strings) {
        if (!str.empty()) {
            non_empty_strings.insert(str);
        }
        if (false == std::none_of(str.begin(), str.end(), [](char c) { return c >= '\0' && c < ' '; }))
            throw std::invalid_argument{"Fail constructor: invalid char in word of initial collection"};
    }
    return non_empty_strings;
}
