//Вставьте сюда своё решение из урока «Очередь запросов» темы «Стек, очередь, дек».‎
#include "request_queue.h"

std::vector<Document> RequestQueue::AddFindRequest(const std::string& raw_query, DocumentStatus status) {
    // напишите реализацию
    auto temp = search_server_.FindTopDocuments(raw_query, status);
    Add(temp.size());
    return temp;
}
std::vector<Document> RequestQueue::AddFindRequest(const std::string& raw_query) {
    // напишите реализацию
    auto temp = search_server_.FindTopDocuments(raw_query);
    Add(temp.size());
    return temp;
}

void RequestQueue::Add(size_t numb) {
    requests_.push_back({numb});
    if (0 == numb)
        ++empty_requests_;
    if (min_in_day_ < requests_.size()) {
        if (0 == requests_.front().numb_request_)
            --empty_requests_;
        requests_.pop_front();
    }
}