#pragma once
#include <cassert>
#include <cstdlib>
#include <new>
#include <utility>
#include <memory>
#include <algorithm>

template <typename T>
class RawMemory {
public:
	RawMemory() = default;
	RawMemory(const RawMemory&) = delete;
	RawMemory& operator=(const RawMemory& rhs) = delete;

	RawMemory(RawMemory&& other) noexcept {
		buffer_ = other.buffer_;
		capacity_ = other.capacity_;
		other.buffer_ = nullptr;
		other.capacity_ = 0;
	}
	RawMemory& operator=(RawMemory&& rhs) noexcept {
		if (this != &rhs) {
			operator delete (buffer_);
			buffer_ = rhs.buffer_;
			capacity_ = rhs.capacity_;
			rhs.buffer_ = nullptr;
			rhs.capacity_ = 0;
		}
		return *this;
	}

	explicit RawMemory(size_t capacity) :
		buffer_(Allocate(capacity)),
		capacity_(capacity) {
	}

	~RawMemory() {
		operator delete(buffer_);
	}

	T* operator+(size_t offset) noexcept {
		// Разрешается получать адрес ячейки памяти, следующей за последним элементом массива
		assert(offset <= capacity_);
		return buffer_ + offset;
	}

	const T* operator+(size_t offset) const noexcept {
		return const_cast<RawMemory&>(*this) + offset;
	}

	const T& operator[](size_t index) const noexcept {
		return const_cast<RawMemory&>(*this)[index];
	}

	T& operator[](size_t index) noexcept {
		assert(index < capacity_);
		return buffer_[index];
	}

	void Swap(RawMemory& other) noexcept {
		std::swap(buffer_, other.buffer_);
		std::swap(capacity_, other.capacity_);
	}

	const T* GetAddress() const noexcept {
		return buffer_;
	}

	T* GetAddress() noexcept {
		return buffer_;
	}

	size_t Capacity() const {
		return capacity_;
	}

private:
	// Выделяет сырую память под n элементов и возвращает указатель на неё
	static T* Allocate(size_t n) {
		return n != 0 ? static_cast<T*>(operator new(n * sizeof(T))) : nullptr;
	}

	void Move(RawMemory&& other) {
		buffer_ = other.buffer_;
		capacity_ = other.capacity_;
		other.buffer_ = nullptr;
		other.capacity_ = 0;
	}

	T* buffer_ = nullptr;
	size_t capacity_ = 0;
};

template <typename T>
class Vector {
public:
	Vector() = default;

	explicit Vector(size_t size)
		: data_(size)
		, size_(size)  //
	{
		std::uninitialized_value_construct_n(data_.GetAddress(), size);
	}
	Vector(const Vector& other) :
		data_{ other.size_ },
		size_{ other.size_}
	{
		std::uninitialized_copy_n(other.data_.GetAddress(), size_,
			data_.GetAddress());
	}
	Vector(Vector&& other) noexcept {
		Swap(other);
	}

	~Vector() {
		std::destroy_n(data_.GetAddress(), size_);
	}

	Vector& operator=(const Vector& rhs) {
		if (this != &rhs) {
			if (rhs.size_ > Capacity()) {
				Vector rhs_copy(rhs);
				Swap(rhs_copy);
			}
			else {
				if (rhs.size_ < size_) {
					std::copy(rhs.data_.GetAddress(), rhs.data_.GetAddress() + rhs.size_, data_.GetAddress());
					std::destroy_n(data_.GetAddress() + rhs.size_, size_ - rhs.size_);
				}
				else {
					std::copy(rhs.data_.GetAddress(), rhs.data_.GetAddress() + size_, data_.GetAddress());
					std::uninitialized_copy_n(rhs.data_.GetAddress() + size_, rhs.size_ - size_, data_.GetAddress() + size_);
				}
				size_ = rhs.size_;
			}
		}
		return *this;
	}
	Vector& operator=(Vector&& rhs) noexcept {
		if (this != &rhs) {
			Swap(rhs);
		}
		return *this;
	}

	size_t Size() const noexcept {
		return size_;
	}

	size_t Capacity() const noexcept {
		return data_.Capacity();
	}

	const T& operator[](size_t index) const noexcept {
		return const_cast<Vector&>(*this)[index];
	}

	T& operator[](size_t index) noexcept {
		assert(index < size_);
		return data_[index];
	}

	void Swap(Vector& other) noexcept {
		data_.Swap(other.data_);
		std::swap(size_, other.size_);
	}
	void Resize(size_t new_size) {
		if (new_size > size_) {
			Reserve(new_size);
			std::uninitialized_value_construct_n(data_.GetAddress() + size_, new_size - size_);
		}
		else {
			std::destroy_n(data_.GetAddress() + new_size, size_ - new_size);
		}
		size_ = new_size;
	}
	void Reserve(size_t new_capacity) {
		if (new_capacity <= Capacity()) {
			return;
		}
		RawMemory<T> new_data{ new_capacity };
		if constexpr (std::is_nothrow_move_constructible_v<T>
			|| !std::is_copy_constructible_v<T>) {
			std::uninitialized_move_n(data_.GetAddress(), size_,
				new_data.GetAddress());
		}
		else {
			std::uninitialized_copy_n(data_.GetAddress(), size_,
				new_data.GetAddress());
		}
		std::destroy_n(data_.GetAddress(), size_);

		data_.Swap(new_data);
	}
	void PopBack() noexcept {
		if (size_ > 0) {
			std::destroy_at(data_.GetAddress() + size_ - 1);
			--size_;
		}
	}

	using iterator = T*;
	using const_iterator = const T*;

	iterator begin() noexcept {
		return data_.GetAddress();
	}
	iterator end() noexcept {
		return data_ + size_;
	}
	const_iterator begin() const noexcept {
		return data_.GetAddress();
	}
	const_iterator end() const noexcept {
		return data_ + size_;
	}
	const_iterator cbegin() const noexcept {
		return data_.GetAddress();
	}
	const_iterator cend() const noexcept {
		return data_ + size_;
	}

	template <typename Type>
	iterator Insert(const_iterator pos, Type&& type) {
		return Emplace(pos, std::forward<Type>(type));
	}
	template <typename Type>
	void PushBack(Type&& value) {
		EmplaceBack(std::forward<Type>(value));
	}
	/*
	Нет это нельзя убирать.
	Алгоритм EmplaceBack и Emplace отличаются. Тесты требует чтобы
	Emplace скопировал поступившие значение во временную переменную,
	а EmplaceBack должен поместить его сразу в одно движение.
	EmplaceBack не возможно просто свести до Emplace добавив итератор end()
	тогда EmplaceBack не будет проходить тесты.
	
	Я могу убрать двойное new и проверку size_, остальное менять нельзя.
	инача в EmplaceNoReplace нужно будет добавлять проверку на принадлежность
	итератора к саомму вектору и делать две ветки в зависимости от результата.
	Станет только сложней, а надобности никакой.
	*/
	template <typename... Args>
	T& EmplaceBack(Args&&... args) {
		iterator result = nullptr;
		if (size_ == Capacity()) {
			result = EmplaceReplace(end(), std::forward<Args>(args)...);
		}
		else {
			result = new (data_ + size_) T(std::forward<Args>(args)...);
		}
		++size_;
		return *result;
	}
	template <typename... Args>
	iterator Emplace(const_iterator pos, Args&&... args) {
		iterator result = nullptr;
		if (size_ == Capacity()) {
			result = EmplaceReplace(pos, std::forward<Args>(args)...);
		}
		else if (size_ != 0) {
			result = EmplaceNoReplace(pos, std::forward<Args>(args)...);
		}
		else {
			result = new (data_.GetAddress()) T(std::forward<Args>(args)...);
		}
		++size_;
		return result;
	}
	iterator Erase(const_iterator pos)
		/* noexcept(std::is_nothrow_move_assignable_v<T>) */ {
		size_t index = pos - begin();
		std::move(begin() + index + 1, end(), begin() + index);
		PopBack();
		return begin() + index;
	}

private:
	RawMemory<T> data_;
	size_t size_ = 0;

	template <typename... Args>
	iterator EmplaceReplace(const_iterator pos, Args&&... args) {
		RawMemory<T> new_data{ size_ ? size_ << 1 : 1 };
		auto index = pos - begin();
		auto result = new (new_data + index) T(std::forward<Args>(args)...);
		if constexpr (std::is_nothrow_move_constructible_v<T>
			|| !std::is_copy_constructible_v<T>) {
			std::uninitialized_move_n(data_.GetAddress(), index,
				new_data.GetAddress());
			std::uninitialized_move_n(data_ + index, size_ - index,
				new_data + index + 1);
		}
		else {
			std::uninitialized_copy_n(data_.GetAddress(), index,
				new_data.GetAddress());
			std::uninitialized_copy_n(data_ + index, size_ - index,
				new_data + index + 1);
		}
		std::destroy_n(data_.GetAddress(), size_);

		data_.Swap(new_data);
		return result;
	}
	template <typename... Args>
	iterator EmplaceNoReplace(const_iterator pos, Args&&... args) {
		auto index = pos - begin();
		T temp(std::forward<Args>(args)...);
		if constexpr (std::is_nothrow_move_constructible_v<T>
			|| !std::is_copy_constructible_v<T>) {
			std::uninitialized_move_n(end() - 1, 1, end());
			std::move_backward(begin() + index, end() - 1, end());
			data_[index] = std::move(temp);
		}
		else {
			std::uninitialized_copy_n(end() - 1, 1, end());
			std::copy_backward(begin() + index, end() - 1, end());
			data_[index] = temp;
		}
		return begin() + index;
	}
};
