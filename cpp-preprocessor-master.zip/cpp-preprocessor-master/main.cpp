#include <cassert>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <regex>
#include <sstream>
#include <string>
#include <vector>
#include <optional>

using namespace std;
using filesystem::path;

path operator""_p(const char* data, std::size_t sz) {
    return path(data, data + sz);
}

bool Parsing(ifstream& in_file, ofstream& out_file, const path& parent_path_filename, const vector<path>& include_directories) {
    static const regex reg_inc[]{ regex{ "\\s*#\\s*include\\s*\"([^\"]*)\"\\s*" },
                                  regex{ "\\s*#\\s*include\\s*<([^>]*)>\\s*" } };
    static const regex reg_dir{ "\\/" };
    static smatch match;

    int number = 1;
    string line;
    getline(in_file, line);
    while (false == in_file.fail()) {
        bool bool_parent_path{false};
        if (false == regex_match(line, match, reg_inc[0]))
            regex_match(line, match, reg_inc[1]);
        else
            bool_parent_path = true;

        if (false == match.empty()) {
            string str{ match[1].str() };
            vector<string> dir{ sregex_token_iterator(cbegin(str), cend(str), reg_dir, -1), sregex_token_iterator{}};
            string file_name = *--dir.end();
            dir.pop_back();
            path include_path{""};
            for (const auto& term : dir)
                include_path /= term;

            path exists{""};
            path parent_path = parent_path_filename.parent_path();
            if (bool_parent_path) {
                auto test = parent_path / include_path / file_name;
                if (filesystem::exists(parent_path / include_path / file_name))
                    exists = parent_path / include_path;
            }
            for (const auto& term : include_directories) {
                if (filesystem::exists(term / include_path / file_name))
                    exists = term / include_path;
            }

            ifstream next_in(exists / file_name);
            if (next_in) {
                if (false == Parsing(next_in, out_file, parent_path / include_path / file_name, include_directories))
                    return false;
            }
            else {
                cout << "unknown include file " << file_name << " at file " << parent_path_filename.generic_string() << " at line " << number;
                return false;
            }
        }
        else {
            out_file << line << endl;
            //cout << line << endl;
        }

        getline(in_file, line);
        ++number;
    }

    return true;
}

// напишите эту функцию
bool Preprocess(const path& in_file, const path& out_file, const vector<path>& include_directories) {
    ifstream in(in_file);
    if (!in)
        return false;

    ofstream out(out_file);
    if (!out)
        return false;

    return Parsing(in, out, in_file, include_directories);
}

string GetFileContents(string file) {
    ifstream stream(file);

    // конструируем string по двум итераторам
    return { (istreambuf_iterator<char>(stream)), istreambuf_iterator<char>() };
}

void Test() {
    error_code err;
    filesystem::remove_all("sources"_p, err);
    filesystem::create_directories("sources"_p / "include2"_p / "lib"_p, err);
    filesystem::create_directories("sources"_p / "include1"_p, err);
    filesystem::create_directories("sources"_p / "dir1"_p / "subdir"_p, err);

    {
        ofstream file("sources/a.cpp");
        file << "// this comment before include\n"
            "#include \"dir1/b.h\"\n"
            "// text between b.h and c.h\n"
            "#include \"dir1/d.h\"\n"
            "\n"
            "int SayHello() {\n"
            "    cout << \"hello, world!\" << endl;\n"
            "#   include<dummy.txt>\n"
            "}\n"s;
    }
    {
        ofstream file("sources/dir1/b.h");
        file << "// text from b.h before include\n"
            "#include \"subdir/c.h\"\n"
            "// text from b.h after include"s;
    }
    {
        ofstream file("sources/dir1/subdir/c.h");
        file << "// text from c.h before include\n"
            "#include <std1.h>\n"
            "// text from c.h after include\n"s;
    }
    {
        ofstream file("sources/dir1/d.h");
        file << "// text from d.h before include\n"
            "#include \"lib/std2.h\"\n"
            "// text from d.h after include\n"s;
    }
    {
        ofstream file("sources/include1/std1.h");
        file << "// std1\n"s;
    }
    {
        ofstream file("sources/include2/lib/std2.h");
        file << "// std2\n"s;
    }

    assert((!Preprocess("sources"_p / "a.cpp"_p, "sources"_p / "a.in"_p,
        { "sources"_p / "include1"_p,"sources"_p / "include2"_p })));

    ostringstream test_out;
    test_out << "// this comment before include\n"
        "// text from b.h before include\n"
        "// text from c.h before include\n"
        "// std1\n"
        "// text from c.h after include\n"
        "// text from b.h after include\n"
        "// text between b.h and c.h\n"
        "// text from d.h before include\n"
        "// std2\n"
        "// text from d.h after include\n"
        "\n"
        "int SayHello() {\n"
        "    cout << \"hello, world!\" << endl;\n"s;

    assert(GetFileContents("sources/a.in"s) == test_out.str());
}

int main() {
    Test();
}
