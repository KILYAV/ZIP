#include "bmp_image.h"
#include "pack_defines.h"

#include <iostream>
#include <array>
#include <fstream>
#include <string_view>

using namespace std;

namespace img_lib {

#define TYPE_HEADE_BMP 0x4D42
#define BIT_COUNT 24
#define X_PELS_PER_METR 11811
#define Y_PELS_PER_METR 11811
#define COUNT_IMPORNT_COLO 0x1000000

PACKED_STRUCT_BEGIN BitmapFileHeader {
    // поля заголовка Bitmap File Header
    uint16_t bfType;      // Тип файла, должен быть 'BM'
    uint32_t bfSize;      // Размер файла в байтах
    uint16_t bfReserved1; // Зарезервировано, должно быть 0
    uint16_t bfReserved2; // Зарезервировано, должно быть 0
    uint32_t bfOffBits;   // Смещение от начала файла до пиксельных
}
PACKED_STRUCT_END

PACKED_STRUCT_BEGIN BitmapInfoHeader {
    // поля заголовка Bitmap Info Header
    uint32_t biSize;          // Размер информационного заголовка, должен быть 40
    int32_t  biWidth;         // Ширина изображения в пикселях
    int32_t  biHeight;        // Высота изображения в пикселях
    uint16_t biPlanes;        // Количество цветовых плоскостей, должно быть 1
    uint16_t biBitCount;      // Количество бит на пиксель
    uint32_t biCompression;   // Тип сжатия, должен быть 0 (без сжатия)
    uint32_t biSizeImage;     // Размер пиксельных данных в байтах
    int32_t  biXPelsPerMeter; // Горизонтальное разрешение в пикселях на метр
    int32_t  biYPelsPerMeter; // Вертикальное разрешение в пикселях на метр
    uint32_t biClrUsed;       // Количество используемых цветов, 0 означает 2^biBitCount
    uint32_t biClrImportant;  // Количество важных цветов, 0 означает все
}
PACKED_STRUCT_END

// функция вычисления отступа по ширине
static int GetBMPStride(int w) {
    return 4 * ((w * 3 + 3) / 4);
}

// напишите эту функцию
bool SaveBMP(const Path& file, const Image& image){
    std::ofstream out(file, std::ios::binary);
    if (!out.is_open()) {
        return false;
    }

    const int width = image.GetWidth();
    const int height = image.GetHeight();
    const int stride = GetBMPStride(width);//(width * 3 + 3) & ~3; // Каждая строка должна начинаться на 4-байтную границу

    BitmapFileHeader fileHeader = {
        .bfType = TYPE_HEADE_BMP, // 'BM'
        .bfSize = static_cast<uint32_t>(sizeof(BitmapFileHeader) + sizeof(BitmapInfoHeader) + stride * height),
        .bfReserved1 = 0,
        .bfReserved2 = 0,
        .bfOffBits = sizeof(BitmapFileHeader) + sizeof(BitmapInfoHeader)
    };

    BitmapInfoHeader infoHeader = {
        .biSize = static_cast<uint32_t>(sizeof(BitmapInfoHeader)),
        .biWidth = width,
        .biHeight = height,
        .biPlanes = 1,
        .biBitCount = BIT_COUNT,
        .biCompression = 0,
        .biSizeImage = static_cast<uint32_t>(stride * height),
        .biXPelsPerMeter = X_PELS_PER_METR, // 300 dpi
        .biYPelsPerMeter = Y_PELS_PER_METR,
        .biClrUsed = 0,
        .biClrImportant = COUNT_IMPORNT_COLO
    };

    out.write(reinterpret_cast<char*>(&fileHeader), sizeof(fileHeader));
    out.write(reinterpret_cast<char*>(&infoHeader), sizeof(infoHeader));

    std::vector<char> row(stride, 0);
    for (int y = height - 1; y >= 0; --y) {
        for (int x = 0; x < width; ++x) {
            row[x * 3 + 2] = static_cast<char>(image.GetPixel(x, y).r); // Red
            row[x * 3 + 1] = static_cast<char>(image.GetPixel(x, y).g); // Green
            row[x * 3 + 0] = static_cast<char>(image.GetPixel(x, y).b); // Blue
        }
        out.write(reinterpret_cast<char*>(row.data()), stride);
    }

    out.close();
    return true;
}

// напишите эту функцию
Image LoadBMP(const Path& file){

    std::ifstream in(file, std::ios::binary);
    if (!in.is_open()) {
        return img_lib::Image();
    }

    BitmapFileHeader fileHeader;
    in.read(reinterpret_cast<char*>(&fileHeader), sizeof(fileHeader));
    if (fileHeader.bfType != TYPE_HEADE_BMP || fileHeader.bfOffBits < sizeof(BitmapFileHeader) + sizeof(BitmapInfoHeader)) {
        return img_lib::Image();
    }

    BitmapInfoHeader infoHeader;
    in.read(reinterpret_cast<char*>(&infoHeader), sizeof(infoHeader));

    if (infoHeader.biBitCount != BIT_COUNT || infoHeader.biCompression != 0) {
        return img_lib::Image();
    }

    const int width = infoHeader.biWidth;
    const int height = infoHeader.biHeight;
    const int stride = (width * 3 + 3) & ~3;

    img_lib::Image image(width, height, Color::Black());
    std::vector<uint8_t> row(stride);

    for (int y = height - 1; y >= 0; --y) {
        in.read(reinterpret_cast<char*>(row.data()), stride);
        for (int x = 0; x < width; ++x) {
            image.GetPixel(x, y).r = static_cast<byte>(row[x * 3 + 2]); // Red
            image.GetPixel(x, y).g = static_cast<byte>(row[x * 3 + 1]); // Green
            image.GetPixel(x, y).b = static_cast<byte>(row[x * 3 + 0]); // Blue
        }
    }

    in.close();
    return image;
}

}  // namespace img_lib
