#pragma once
#include <map>
#include <utility>
#include <iostream>
#include <optional>

#include "router.h"
//#include "request_handler.h"
#include "transport_catalogue.h"

namespace router {
	struct RouterSetting {
		int bus_wait_time{ 0 };
		double bus_velocity{ 0. };
	};

	using Edge = graph::Edge<double>;
	using Graph = graph::DirectedWeightedGraph<double>;
	using Router = graph::Router<double>;

	struct RouteInfo {
		struct Edge {
			std::string name;
			int count;
			double weight;
		};
			
		double weight;
		std::vector<Edge> edges;
	};

	class TransportRouter {
		Graph graph;
		Router router;

		struct Distance;
		class BuilderGraph {
			const TransportCatalogue& catalogue;
			const RouterSetting& setting;

			const double division;
			const size_t count;

			Graph graph;

			std::vector<Distance> BuilderDistance(
				const std::vector<const domain::Stop*>& stops);
			std::vector<Distance> BuilderDistanceReverse(
				const std::vector<const domain::Stop*>& stops);
			void StopsGraph();
			void BusesGraph();
			void AddsEdges(const std::vector<Distance>&, const std::string&);

		public:
			BuilderGraph(const TransportCatalogue& catalogue,
				const RouterSetting& setting);
			Graph Release();
		};

	public:
		template<class C, class S>
		TransportRouter(C&& catalogue, S&& setting) :
			graph{ BuilderGraph{ std::forward<C>(catalogue),
				std::forward<S>(setting) }.Release() },
			router{ graph }
		{}

		std::optional<RouteInfo> BuilderRoute(
			std::string_view, std::string_view) const;
	};
} // namespace router