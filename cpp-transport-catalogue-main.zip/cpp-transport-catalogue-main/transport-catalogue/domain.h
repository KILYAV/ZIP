#pragma once

#include "geo.h"
#include <string>
#include <vector>

namespace domain {
	struct Stop {
		std::string name;
		geo::Coordinates coor;
	};
	struct Bus {
		std::string name;
		std::vector<const Stop*> stops;
		bool is_roundtrip;
	};
	struct InfoBus {
		int count_stops;
		int count_uniqum_stops;
		double lenght;
		double curvature;
	};

	using InfoStop = std::set<std::string_view>;
}