#pragma once
#include <set>
#include <deque>
#include <string>
#include <vector>
#include <numeric>
#include <iostream>
#include <optional>
#include <algorithm>
#include <string_view>
#include <unordered_set>
#include <unordered_map>

#include "domain.h"

class TransportCatalogue {
public:
	void AddStop(const std::string_view stop, const geo::Coordinates& coor);
	void AddBus(const std::string_view bus, const std::vector<std::string_view>& route, const bool);
	void SetLenght(const std::string_view start, const std::string_view finish, double lenght);
	std::optional<double> GetLenght(const std::string_view start, const std::string_view finis) const;

	const std::optional<domain::InfoBus> GetBusInfo(const std::string_view bus) const;
	const std::optional<domain::InfoStop> GetStopInfo(const std::string_view stop) const;

	const std::deque<domain::Bus>& GetBusesList() const;
	const std::deque<domain::Stop>& GetStopsList() const;

private:
	std::deque<domain::Bus> buses_;
	std::deque<domain::Stop> stops_;

	std::unordered_map<std::string_view, domain::Bus*> search_bus;
	std::unordered_map<std::string_view, domain::Stop*> search_stop;
	std::unordered_map<std::string_view, std::set<std::string_view>> stops_buses;

	struct hash_map {
		size_t operator() (const std::pair<const domain::Stop*,
			const domain::Stop*>& start_finish) const {
			auto start = std::hash<const void*>{}(start_finish.first);
			auto finish = std::hash<const void*>{}(start_finish.second);
			return start + finish * 37;
		}
	};
	std::unordered_map<std::pair<const domain::Stop*, const domain::Stop*>,
		double, hash_map> lenghts_;
};