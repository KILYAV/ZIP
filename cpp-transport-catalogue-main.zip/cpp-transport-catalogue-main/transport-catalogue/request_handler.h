#pragma once
#include <iostream>
#include <functional>

#include "map_renderer.h"
#include "transport_router.h"
#include "transport_catalogue.h"

class RequestHandler {
	const TransportCatalogue& catalogue;
	const router::TransportRouter& router;
	const renderer::MapRenderer& renderer;
public:
	RequestHandler(const TransportCatalogue& catalogue,
		const router::TransportRouter& router,
		const renderer::MapRenderer& renderer);

	renderer::InfoMap MapRequest() const;
	std::optional<domain::InfoBus> BusRequest(std::string_view) const;
	std::optional<domain::InfoStop> StopRequest(std::string_view) const;
	std::optional<router::RouteInfo> RouteRequest(
		std::string_view start, std::string_view finish) const;
};

/*
namespace router {
	struct RouteInfo;
	class TransportRouter;
}
namespace request {
	struct Map;
	struct Bus {
		std::string name;
		int id;
	};
	struct Stop {
		std::string name;
		int id;
	};
	struct Route;
	struct InfoBus {
		std::optional<domain::InfoBus> bus;
		int id;
	};
	struct InfoStop {
		std::optional<domain::InfoStop> stop;
		int id;
	};
	using inner_variant = std::variant<Map, Bus, Stop, Route>;
	using onner_variant = std::variant<renderer::InfoMap, 
		InfoBus, InfoStop, router::RouteInfo>;

	struct InfoRequest : std::vector<onner_variant> {};

	class RequestHandler {
		std::vector<inner_variant> variants;

	public:
		RequestHandler(std::vector<inner_variant>&&);
		RequestHandler(const std::vector<inner_variant>&);

		InfoRequest Request(const TransportCatalogue&,
			const renderer::MapRenderer&,
			const router::TransportRouter&) const;
	};
}
*/