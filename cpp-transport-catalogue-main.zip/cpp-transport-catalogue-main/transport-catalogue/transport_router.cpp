#include "transport_router.h"

using namespace router;

std::optional<graph::EdgeId> GetEdgeId(const Graph& graph,
	std::string_view stop) {
	auto count{ graph.GetVertexCount() / 2 };
	for (size_t index = 0; index < count; ++index) {
		if (graph.GetEdge(index).name == stop)
			return index;
	}
	return std::nullopt;
}

constexpr double meter_in_kilometer = 1000;
constexpr double second_in_minute = 60;

TransportRouter::BuilderGraph::BuilderGraph(const TransportCatalogue& catalogue,
	const RouterSetting& setting) :
	catalogue{ catalogue },
	setting{ setting },
	division{ meter_in_kilometer / second_in_minute * setting.bus_velocity },
	count{ catalogue.GetStopsList().size() }
{}
struct TransportRouter::Distance {
	union {
		std::string_view name;
		graph::EdgeId id;
	} vertex;
	double distance;
};
std::vector<TransportRouter::Distance>
TransportRouter::BuilderGraph::BuilderDistance(
	const std::vector<const domain::Stop*>& stops) {
	std::vector<Distance> distances;
	distances.push_back({ {stops.front()->name}, 0. });

	for (size_t prev = 0, next = 1, size = stops.size(); next < size;
		++prev, ++next) {
		distances.push_back({ stops[next]->name,
			catalogue.GetLenght(stops[prev]->name, stops[next]->name).value() });
	}
	for (auto& [vertex, _] : distances) {
		vertex.id =
			graph.GetEdge(GetEdgeId(graph, vertex.name).value()).from;
	}
	return distances;
}
std::vector<TransportRouter::Distance>
TransportRouter::BuilderGraph::BuilderDistanceReverse(
	const std::vector<const domain::Stop*>& stops) {
	std::vector<const domain::Stop*> reverse;
	reverse.reserve(stops.size());
	for (auto iter = stops.rbegin(), end = stops.rend(); iter != end; ++iter) {
		reverse.push_back(*iter);
	}
	return BuilderDistance(reverse);
}
void TransportRouter::BuilderGraph::StopsGraph() {
	const auto& stops{ catalogue.GetStopsList() };
	size_t count{ stops.size() };

	graph = Graph{ count * 2 };
	for (size_t index = 0; index < count; ++index) {
		graph.AddEdge({
			stops[index].name,
			0,
			index,
			index + count,
			static_cast<double>(setting.bus_wait_time) });
	}
}
void TransportRouter::BuilderGraph::AddsEdges(
	const std::vector<Distance>& distances,
	const std::string& name) {
	for (size_t prev = 0, size = distances.size(); prev + 1 < size; ++prev) {
		double sum_distance{ 0 };
		for (size_t next = prev + 1; next < size; ++next) {
			sum_distance += distances[next].distance;
			graph.AddEdge({
				name,
				static_cast<int>(next - prev),
				distances[prev].vertex.id + count,
				distances[next].vertex.id,
				sum_distance / division });
		}
	}
}
void TransportRouter::BuilderGraph::BusesGraph() {
	for (const auto& [name, stops, is_roundtrip] : catalogue.GetBusesList()) {
		auto distances = BuilderDistance(stops);
		AddsEdges(distances, name);
		/*
		Я нахожу такую форма записи значительно более удобной,
		чем добавление восклицательного знака который ... заметишь
		*/
		if (false == is_roundtrip) {
			auto distances = BuilderDistanceReverse(stops);
			AddsEdges(distances, name);
		}
	}
}

Graph TransportRouter::BuilderGraph::Release() {
	StopsGraph();
	BusesGraph();
	return std::move(graph);
}
std::optional<RouteInfo> TransportRouter::BuilderRoute(
	std::string_view start, std::string_view finish) const {
	auto start_opt{ GetEdgeId(graph, start) };
	auto finish_opt{ GetEdgeId(graph, finish) };
	if (start_opt && finish_opt) {
		auto& start{ graph.GetEdge(start_opt.value()).from };
		auto& finish{ graph.GetEdge(finish_opt.value()).from };
		auto route_info_opt{ router.BuildRoute(start, finish) };
		if (route_info_opt) {
			auto& route_info{ route_info_opt.value() };
			RouteInfo edges_info{ route_info.weight, {} };
			auto& edges{ edges_info.edges };
			for (const auto EdgeId : route_info.edges) {
				auto& edge{ graph.GetEdge(EdgeId) };
				edges.push_back(
					RouteInfo::Edge{
						edge.name,
						edge.count,
						edge.weight
						});
			}
			return { edges_info };
		}
	}
	return { std::nullopt };
}