#include "json_reader.h"

JsonReader::JsonReader(Document&& document) :
	document_{ std::move(document) }
{}
JsonReader::JsonReader(const Document& document) :
	document_{ document }
{}

JsonReader& JsonReader::ReadDocument(Document&& document) {
	document_ = std::move(document);
	return *this;
}
JsonReader& JsonReader::ReadDocument(const Document& document) {
	document_ = document;
	return *this;
}

void JsonReader::LoadStops(TransportCatalogue& catalogue, const Array& base_requests) const {
	for (const auto& node : base_requests) {
		auto& dict{ node.AsDict() };
		if ("Stop" == dict.at("type").AsString()) {
			catalogue.AddStop(dict.at("name").AsString(),
				{ dict.at("latitude").AsDouble(), dict.at("longitude").AsDouble() });
		}
	}
}
void JsonReader::LoadBuses(TransportCatalogue& catalogue, const Array& base_requests) const {
	for (const auto& node : base_requests) {
		const auto& dict{ node.AsDict() };
		if ("Bus" == dict.at("type").AsString()) {
			std::vector<std::string_view> route;
			for (const auto& stop : dict.at("stops").AsArray()) {
				route.push_back(stop.AsString());
			}
			catalogue.AddBus(dict.at("name").AsString(), route,
				dict.at("is_roundtrip").AsBool());
		}
	}
}
void JsonReader::LoadLength(TransportCatalogue& catalogue, const Array& base_requests) const {
	for (const auto& node : base_requests) {
		const auto& dict{ node.AsDict() };
		if (dict.contains("road_distances")) {
			const auto& start{ dict.at("name").AsString() };
			for (const auto& [finish, node] : dict.at("road_distances").AsDict()) {
				const auto& lenght{ node.AsDouble() };
				catalogue.SetLenght(start, finish, lenght);
			}
		}
	}
}

std::optional<TransportCatalogue> JsonReader::ReadCatalogue() const {
	return ReadCatalogue(document_);
}
std::optional<TransportCatalogue> JsonReader::ReadCatalogue(Document&& document) const {
	return ReadCatalogue(document);
}
std::optional<TransportCatalogue> JsonReader::ReadCatalogue(const Document& document) const {
	TransportCatalogue catalogue;

	if (document.GetRoot().AsDict().contains("base_requests")) {
		auto& base_requests{
			document.GetRoot().AsDict().at("base_requests").AsArray()};
		LoadStops(catalogue, base_requests);
		LoadBuses(catalogue, base_requests);
		LoadLength(catalogue, base_requests);
		return catalogue;
	}
	else
		return std::nullopt;
}

std::optional<router::RouterSetting> JsonReader::ReadRouterSetting() const {
	return ReadRouterSetting(document_);
}
std::optional<router::RouterSetting> JsonReader::ReadRouterSetting(Document&& document) const {
	return ReadRouterSetting(document);
}
std::optional<router::RouterSetting> JsonReader::ReadRouterSetting(const Document& document) const {
	router::RouterSetting settings;

	auto i_routing_settings{ document.GetRoot().AsDict().find("routing_settings") };
	if (i_routing_settings != document.GetRoot().AsDict().end()) {
		auto dict{ i_routing_settings->second.AsDict() };
		settings.bus_wait_time = dict.at("bus_wait_time").AsInt();
		settings.bus_velocity = dict.at("bus_velocity").AsDouble();
		return settings;
	}
	else
		return std::nullopt;
}

std::optional<renderer::MapRenderer> JsonReader::ReadRenderer() const {
	return ReadRenderer(document_);
}
std::optional<renderer::MapRenderer> JsonReader::ReadRenderer(
	Document&& document) const {
	return ReadRenderer(document);
}
std::optional<renderer::MapRenderer> JsonReader::ReadRenderer(
	const Document& document) const {
	renderer::SettingsRenderer settings;

	auto i_render_settings{ document.GetRoot().AsDict().find("render_settings") };
	if (i_render_settings != document.GetRoot().AsDict().end()) {
		auto dict{ i_render_settings->second.AsDict() };
		settings.width = dict.at("width").AsDouble();
		settings.height = dict.at("height").AsDouble();
		settings.padding = dict.at("padding").AsDouble();
		settings.line_width = dict.at("line_width").AsDouble();
		settings.stop_radius = dict.at("stop_radius").AsDouble();
		settings.bus_label_font_size = dict.at("bus_label_font_size").AsInt();
		settings.bus_label_offset.x = dict.at("bus_label_offset").AsArray().front().AsDouble();
		settings.bus_label_offset.y = dict.at("bus_label_offset").AsArray().back().AsDouble();
		settings.stop_label_font_size = dict.at("stop_label_font_size").AsInt();
		settings.stop_label_offset.x = dict.at("stop_label_offset").AsArray().front().AsDouble();
		settings.stop_label_offset.y = dict.at("stop_label_offset").AsArray().back().AsDouble();

		auto Color = [&](const Node& node) {
			if (node.IsString()) {
				return svg::Color{ node.AsString() };
			}
			else {
				auto& array{ node.AsArray() };
				uint8_t rgb[]{ static_cast<uint8_t>(array[0].AsInt()),
					static_cast<uint8_t>(array[1].AsInt()),
					static_cast<uint8_t>(array[2].AsInt()) };
				if (4 == array.size()) {
					return svg::Color{ svg::Rgba{ rgb[0], rgb[1], rgb[2], array[3].AsDouble() } };
				}
				else {
					return svg::Color{ svg::Rgb{ rgb[0], rgb[1], rgb[2] } };
				}
			}
			};

		settings.underlayer_color = Color(dict.at("underlayer_color"));
		settings.underlayer_width = dict.at("underlayer_width").AsDouble();

		for (auto& color : dict.at("color_palette").AsArray()) {
			settings.color_palette.push_back(Color(color));
		}

		return renderer::MapRenderer{ settings };
	}
	else
		return std::nullopt;
}

json::Node  JsonReader::ExecuteRequest(const RequestHandler& request) const {
	return ExecuteRequest(request, document_);
}
json::Node  JsonReader::ExecuteRequest(const RequestHandler& request,
	Document&& document) const {
	return ExecuteRequest(request, document);
}
json::Node JsonReader::ExecuteRequest(const RequestHandler& request,
	const Document& document) const {
	if (document.GetRoot().AsDict().contains("stat_requests")) {
		json::Array result;
		for (const auto& node :
			document.GetRoot().AsDict().at("stat_requests").AsArray()) {
			auto& data{ node.AsDict() };
			auto& type{ data.at("type").AsString() };
			if ("Map" == type) {
				result.push_back(
					TranslateMapInfo(
						request.MapRequest(),
						data.at("id").AsInt()));
			}
			if ("Bus" == type) {
				result.push_back(
					TranslateBusInfo(
						request.BusRequest(
							data.at("name").AsString()),
						data.at("id").AsInt()));
			}
			if ("Stop" == type) {
				result.push_back(
					TranslateStopInfo(
						request.StopRequest(
							data.at("name").AsString()),
						data.at("id").AsInt()));
			}
			if ("Route" == type) {
				result.push_back(
					TranslateRouteInfo(
						request.RouteRequest(
							data.at("from").AsString(),
							data.at("to").AsString()),
						data.at("id").AsInt()));
			}
		}
		return result;
	}
	else
		return {};
}

json::Node JsonReader::ReadAndExecute() const {
	return ReadAndExecute(document_);
}
json::Node JsonReader::ReadAndExecute(Document&& document) const {
	return ReadAndExecute(document);
}
json::Node JsonReader::ReadAndExecute(const Document& document) const {
	auto catalogue{ ReadCatalogue(document).value() };
	auto router{ router::TransportRouter{ catalogue,
		ReadRouterSetting(document).value() } };
	auto renderer{ ReadRenderer(document).value()};

	RequestHandler request{ catalogue, router, renderer };

	return ExecuteRequest(request, document);
}

json::Array JsonReader::TranslateEdgeRoute(
	const std::vector<router::RouteInfo::Edge>& edges) const {
	json::Array items;
	for (auto& edge : edges) {
		if (edge.count) {
			items.push_back(
				json::Builder{}
				.StartDict()
				.Key("bus")
				.Value(edge.name)
				.Key("time")
				.Value(edge.weight)
				.Key("type")
				.Value("Bus")
				.Key("span_count")
				.Value(edge.count)
				.EndDict()
				.Build()
			);
		}
		else {
			items.push_back(
				json::Builder{}
				.StartDict()
				.Key("stop_name")
				.Value(edge.name)
				.Key("time")
				.Value(edge.weight)
				.Key("type")
				.Value("Wait")
				.EndDict()
				.Build()
			);
		}
	}
	return items;
}
json::Node JsonReader::TranslateMapInfo(const renderer::InfoMap& map_info,
	const int id) const {
	return
		json::Builder{}
		.StartDict()
		.Key("request_id")
		.Value(id)
		.Key("map")
		.Value(std::move(static_cast<std::string>(map_info)))
		.EndDict()
		.Build();
}
json::Node JsonReader::TranslateBusInfo(const std::optional<domain::InfoBus>& bus_info,
	const int id) const {
	if (bus_info) {
		auto& bus{ bus_info.value()};
		return
			json::Builder{}
			.StartDict()
			.Key("request_id")
			.Value(id)
			.Key("curvature")
			.Value(bus.curvature)
			.Key("route_length")
			.Value(bus.lenght)
			.Key("stop_count")
			.Value(bus.count_stops)
			.Key("unique_stop_count")
			.Value(bus.count_uniqum_stops)
			.EndDict()
			.Build();
	}
	else
		return
			json::Builder{}
			.StartDict()
			.Key("request_id")
			.Value(id)
			.Key("error_message")
			.Value("not found")
			.EndDict()
			.Build();
}
json::Node JsonReader::TranslateStopInfo(
	const std::optional<domain::InfoStop>& stop_info, const int id) const {
	if (stop_info) {
		auto& stop{ stop_info.value() };
		return
			json::Builder{}
			.StartDict()
			.Key("request_id")
			.Value(id)
			.Key("buses")
			.Value(std::invoke([&] {
				json::Array route;
				for (auto& bus : stop) {
					route.push_back(std::string{ bus });
				}
				return route;
				}))
			.EndDict()
			.Build();
	}
	else
		return
			json::Builder{}
			.StartDict()
			.Key("request_id")
			.Value(id)
			.Key("error_message")
			.Value("not found")
			.EndDict()
			.Build();
}

json::Node JsonReader::TranslateRouteInfo(
	std::optional<router::RouteInfo>&& route,
	const int id) const {
	return TranslateRouteInfo(route, id);
}
json::Node JsonReader::TranslateRouteInfo(
	const std::optional<router::RouteInfo>& route,
	const int id) const {
	if (route) {
		auto& bus{ route.value() };
		return
			json::Builder{}
			.StartDict()
			.Key("request_id")
			.Value(id)
			.Key("total_time")
			.Value(bus.weight)
			.Key("items")
			.Value(TranslateEdgeRoute(bus.edges))
			.EndDict()
			.Build();
	}
	else
		return
			json::Builder{}
			.StartDict()
			.Key("request_id")
			.Value(id)
			.Key("error_message")
			.Value("not found")
			.EndDict()
			.Build();
}
/*
json::Node JsonReader::TranslateRequestInfo(
	const request::InfoRequest& request_info) const {
	json::Array result;
	for (const auto& request : request_info) {
		if (std::holds_alternative<renderer::InfoMap>(request)) {
			result.push_back(
				TranslateMapInfo(std::get<renderer::InfoMap>(request)));
		}
		if (std::holds_alternative<request::InfoBus>(request)) {
			result.push_back(
				TranslateBusInfo(std::get<request::InfoBus>(request)));
		}
		if (std::holds_alternative<request::InfoStop>(request)) {
			result.push_back(
				TranslateStopInfo(std::get<request::InfoStop>(request)));
		}
		if (std::holds_alternative<router::RouteInfo>(request)) {
			result.push_back(
				TranslateRouteInfo(std::get<router::RouteInfo>(request)));
		}
	}
	return result;
}
*/