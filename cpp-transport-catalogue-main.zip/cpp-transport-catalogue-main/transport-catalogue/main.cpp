#include <sstream>
#include <iostream>

#include "json_reader.h"
#include "json_builder.h"
#include "request_handler.h"

int main() {
	Print(json::Document{ JsonReader{}.ReadAndExecute(Load(std::cin)) }, std::cout);
}