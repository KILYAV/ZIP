#pragma once
#include <functional>

#include "json.h"
#include "json_builder.h"
#include "map_renderer.h"
#include "request_handler.h"
#include "transport_router.h"
#include "transport_catalogue.h"

using namespace json;

class JsonReader {
	Document document_{ Node{ nullptr } };

	void LoadStops(TransportCatalogue&, const Array&) const;
	void LoadBuses(TransportCatalogue&, const Array&) const;
	void LoadLength(TransportCatalogue&, const Array&) const;

	json::Array TranslateEdgeRoute(
		const std::vector<router::RouteInfo::Edge>&) const;

public:
	JsonReader() = default;
	JsonReader(Document&&);
	JsonReader(const Document&);

	JsonReader& ReadDocument(Document&&);
	JsonReader& ReadDocument(const Document&);

	std::optional<TransportCatalogue> ReadCatalogue() const;
	std::optional<TransportCatalogue> ReadCatalogue(Document&&) const;
	std::optional<TransportCatalogue> ReadCatalogue(const Document&) const;

	std::optional<router::RouterSetting> ReadRouterSetting() const;
	std::optional<router::RouterSetting> ReadRouterSetting(Document&&) const;
	std::optional<router::RouterSetting> ReadRouterSetting(const Document&) const;

	json::Node ExecuteRequest(const RequestHandler&) const;
	json::Node ExecuteRequest(const RequestHandler&, Document&&) const;
	json::Node ExecuteRequest(const RequestHandler&, const Document&) const;
	
	std::optional<renderer::MapRenderer> ReadRenderer() const;
	std::optional<renderer::MapRenderer> ReadRenderer(Document&&) const;
	std::optional<renderer::MapRenderer> ReadRenderer(const Document&) const;
	
	json::Node ReadAndExecute() const;
	json::Node ReadAndExecute(Document&&) const;
	json::Node ReadAndExecute(const Document&) const;
	
	json::Node TranslateMapInfo(const renderer::InfoMap&, const int id) const;
	json::Node TranslateBusInfo(const std::optional<domain::InfoBus>&,
		const int id) const;
	json::Node TranslateStopInfo(const std::optional<domain::InfoStop>&,
		const int id) const;

	json::Node TranslateRouteInfo(std::optional<router::RouteInfo>&&,
		const int id) const;
	json::Node TranslateRouteInfo(const std::optional<router::RouteInfo>&,
		const int id) const;
	
	//json::Node TranslateRequestInfo(const request::InfoRequest&) const;
};