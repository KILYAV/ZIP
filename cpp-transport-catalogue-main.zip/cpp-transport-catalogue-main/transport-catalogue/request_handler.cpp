#include "request_handler.h"

RequestHandler::RequestHandler(
	const TransportCatalogue& catalogue,
	const router::TransportRouter& router,
	const renderer::MapRenderer& renderer) :
	catalogue{ catalogue },
	router{ router },
	renderer{ renderer }
{}
renderer::InfoMap RequestHandler::MapRequest() const {
	return renderer.BuilderMap(catalogue);
}
std::optional<domain::InfoBus> RequestHandler::BusRequest(
	std::string_view name) const {
	return catalogue.GetBusInfo(name);
}
std::optional<domain::InfoStop> RequestHandler::StopRequest(
	std::string_view name) const {
	return catalogue.GetStopInfo(name);
}
std::optional<router::RouteInfo> RequestHandler::RouteRequest(
	std::string_view start, std::string_view finish) const {
	return router.BuilderRoute(start, finish);
}
/*
RequestHandler::RequestHandler(std::vector<inner_variant>&& variant) :
	variants{ std::move(variant) }
{}
RequestHandler::RequestHandler(const std::vector<inner_variant>& variant) :
	variants{ variant }
{}
InfoRequest RequestHandler::Request(const TransportCatalogue& catalogue,
	const renderer::MapRenderer& renderer,
	const router::TransportRouter& router) const {

	InfoRequest request_info;
	for (auto& variant : variants) {
		if (std::holds_alternative<Map>(variant)) {
			request_info.push_back(
				renderer.BuilderMap(catalogue, std::get<Map>(variant)));
		}
		if (std::holds_alternative<Bus>(variant)) {
			auto info_bus_opt{
				catalogue.GetBusInfo(std::get<Bus>(variant).name) };
			if (info_bus_opt) {
				request_info.push_back(InfoBus{ info_bus_opt.value(),
					std::get<Bus>(variant).id });
			}
			else {
				request_info.push_back(InfoBus{ std::nullopt,
					std::get<Bus>(variant).id });
			}
		}
		if (std::holds_alternative<Stop>(variant)) {
			auto info_stop_opt{
				catalogue.GetStopInfo(std::get<Stop>(variant).name) };
			if (info_stop_opt) {
				request_info.push_back(InfoStop{ info_stop_opt.value(),
					std::get<Stop>(variant).id });
			}
			else {
				request_info.push_back(InfoStop{ std::nullopt,
					std::get<Stop>(variant).id });
			}
		}
		if (std::holds_alternative<Route>(variant)) {
			request_info.push_back(
				router.BuilderRoute(std::get<Route>(variant)));
		}
	}

	return request_info;
}
*/