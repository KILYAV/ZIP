#include "map_renderer.h"

using namespace domain;
using namespace renderer;

bool renderer::IsZero(double value) {
	return std::abs(value) < EPSILON;
}

MapRenderer::MapRenderer(SettingsRenderer&& settings) :
	settings_{ std::move(settings) }
{}
MapRenderer::MapRenderer(const SettingsRenderer& settings) :
	settings_{ settings }
{}

InfoMap MapRenderer::BuilderMap(const TransportCatalogue& catalogue) const {
	PointBusSet list_buses_p{ MakePointBusSet(catalogue) };
	PointStopSet list_stops_p{ MakePointStopSet(list_buses_p) };
	SphereProjector projector{ MakeProjector(list_stops_p) };

	svg::Document document;
	AddLinesBuses(projector, list_buses_p, document);
	AddNumberBuses(projector, list_buses_p, document);
	AddNameStops(projector, list_stops_p, document);

	std::ostringstream buff;
	document.Render(buff);
	return { std::move(buff.str()) };
}

MapRenderer::PointBusSet MapRenderer::MakePointBusSet(const TransportCatalogue& catalogue) const {
	PointBusSet buses_list_p;
	for (const auto& bus : catalogue.GetBusesList()) {
		if (bus.stops.size())
			buses_list_p.insert(&bus);
	}
	return buses_list_p;
}
MapRenderer::PointStopSet MapRenderer::MakePointStopSet(const PointBusSet& list_buses_p) const {
	PointStopSet stops;
	for (const auto& bus : list_buses_p) {
		for (const auto& stop : bus->stops) {
			stops.insert(stop);
		}
	}
	return stops;
}
SphereProjector MapRenderer::MakeProjector(const PointStopSet& list_stops_p) const {
	std::vector<geo::Coordinates> coores;
	for (const auto& stop : list_stops_p) {
		coores.push_back(stop->coor);
	}

	return { coores.begin(), coores.end(), settings_.width, settings_.height,
		settings_.padding };
}

void MapRenderer::AddLinesBuses(const SphereProjector& projector,
	const PointBusSet& list_buses_p, svg::Document& document) const {
	auto color_cur_p{ settings_.color_palette.begin() };
	auto color_end_p{ settings_.color_palette.end() };
	for (const auto& bus : list_buses_p) {
		const auto& stops{ bus->stops };
		svg::Polyline polyline;
		for (const auto& stop : stops) {
			polyline.AddPoint(projector(stop->coor));
		}
		if (false == bus->is_roundtrip) {
			for (auto curr = std::next(stops.rbegin(), 1),
				end = stops.rend(); curr != end; ++curr) {
				polyline.AddPoint(projector((*curr)->coor));
			}
		}

		if (color_end_p == color_cur_p) {
			color_cur_p = settings_.color_palette.begin();
		}
		polyline
			.SetFillColor("none")
			.SetStrokeWidth(settings_.line_width)
			.SetStrokeLineCap(svg::StrokeLineCap::ROUND)
			.SetStrokeLineJoin(svg::StrokeLineJoin::ROUND)
			.SetStrokeColor(*color_cur_p++);

		document.Add(polyline);
	}
}
void MapRenderer::AddNumberBuses(const SphereProjector& projector,
	const PointBusSet& list_buses_p, svg::Document& document) const {
	auto color_cur_p{ settings_.color_palette.begin() };
	const auto color_end_p{ settings_.color_palette.end() };
	for (const auto& bus_p : list_buses_p) {
		if (color_end_p == color_cur_p) {
			color_cur_p = settings_.color_palette.begin();
		}
		svg::Text stroke, text;
		stroke
			.SetData(bus_p->name)
			.SetPosition(projector(bus_p->stops.front()->coor))
			.SetOffset(settings_.bus_label_offset)
			.SetFontSize(settings_.bus_label_font_size)
			.SetFontFamily("Verdana")
			.SetFontWeight("bold");
		text = stroke;
		stroke
			.SetFillColor(settings_.underlayer_color)
			.SetStrokeColor(settings_.underlayer_color)
			.SetStrokeWidth(settings_.underlayer_width)
			.SetStrokeLineCap(svg::StrokeLineCap::ROUND)
			.SetStrokeLineJoin(svg::StrokeLineJoin::ROUND);
		text
			.SetFillColor(*color_cur_p++);
		document.Add(stroke);
		document.Add(text);

		if (false == bus_p->is_roundtrip) {
			if (bus_p->stops.front()->coor != bus_p->stops.back()->coor) {
				stroke.SetPosition(projector(bus_p->stops.back()->coor));
				text.SetPosition(projector(bus_p->stops.back()->coor));
				document.Add(stroke);
				document.Add(text);
			}
		}
	}
}
void MapRenderer::AddNameStops(SphereProjector& projector,
	const PointStopSet& list_stops_p, svg::Document& document) const {
	for (const auto& stop_p : list_stops_p) {
		svg::Circle circle;
		circle
			.SetCenter(projector(stop_p->coor))
			.SetRadius(settings_.stop_radius)
			.SetFillColor("white");
		document.Add(circle);
	}
	for (const auto& stop_p : list_stops_p) {
		svg::Text stroke, text;
		stroke
			.SetData(stop_p->name)
			.SetPosition(projector(stop_p->coor))
			.SetOffset(settings_.stop_label_offset)
			.SetFontSize(settings_.stop_label_font_size)
			.SetFontFamily("Verdana");
		text = stroke;
		stroke
			.SetFillColor(settings_.underlayer_color)
			.SetStrokeColor(settings_.underlayer_color)
			.SetStrokeWidth(settings_.underlayer_width)
			.SetStrokeLineCap(svg::StrokeLineCap::ROUND)
			.SetStrokeLineJoin(svg::StrokeLineJoin::ROUND);
		text
			.SetFillColor("black");
		document.Add(stroke);
		document.Add(text);
	}
}