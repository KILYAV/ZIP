#pragma once

namespace geo {

    struct Coordinates {
        double lat; // Широта
        double lng; // Долгота

        bool operator== (const Coordinates other) const {
            return this->lat == other.lat && this->lng == other.lng;
        }
        bool operator!= (const Coordinates other) const {
            return !(*this == other);
        }
    };

    double ComputeDistance(Coordinates from, Coordinates to);

}  // namespace geo