#include "transport_catalogue.h"

using namespace domain;

void TransportCatalogue::AddStop(const std::string_view stop, const geo::Coordinates& coor) {
	stops_.push_back({ std::string{ stop }, coor });
	search_stop.insert({ stops_.back().name, &stops_.back() });
	stops_buses[stops_.back().name];
}
void TransportCatalogue::AddBus(const std::string_view bus_name, const std::vector<std::string_view>& route_name, const bool is_roundtrip) {
	std::vector<const Stop*> stops;

	for (auto& stop : route_name) {
		stops.push_back(search_stop[stop]);
	}

	buses_.push_back({ std::string{ bus_name }, std::move(stops), is_roundtrip });
	search_bus.insert({ buses_.back().name, &buses_.back() });

	for (auto& stop : buses_.back().stops) {
		stops_buses[stop->name].insert(buses_.back().name);
	}
}
void TransportCatalogue::SetLenght(const std::string_view start, const std::string_view finish, double lenght) {
	lenghts_[{ search_stop[start], search_stop[finish]}] = lenght;
}
std::optional<double> TransportCatalogue::GetLenght(const std::string_view start,
	const std::string_view finish) const {
	if (search_stop.contains(start) && search_stop.contains(finish)) {
		using pair_t = std::pair<const domain::Stop*, const domain::Stop*>;
		pair_t pair{ search_stop.at(start), search_stop.at(finish) };
		if (lenghts_.contains(pair))
			return lenghts_.at(pair);
		else {
			pair = { search_stop.at(finish), search_stop.at(start) };
			if (lenghts_.contains(pair))
				return lenghts_.at(pair);
		}
	}
	return { std::nullopt };
}
const std::optional<domain::InfoBus> TransportCatalogue::GetBusInfo(const std::string_view bus_name) const {
	if (search_bus.contains(bus_name)) {
		auto& bus{ search_bus.at(bus_name) };
		auto& stops{ bus->stops };
		auto& is_roundtrip{ bus->is_roundtrip };
		auto count_stops{ is_roundtrip ? stops.size() : stops.size() * 2 - 1 };
		std::set<std::string_view> unique_stops;
		for (auto& stop : stops) {
			unique_stops.insert(stop->name);
		}

		double lenght{ 0.0 };
		double distance{ 0.0 };
		for (auto prey = stops.begin(), next = std::next(prey, 1), end = stops.end();
			next != end; ++prey, ++next) {
			auto& start{ **prey };
			auto& finish{ **next };
			distance += ComputeDistance(start.coor, finish.coor);
			std::pair<const Stop*, const Stop*> route{ *prey, *next };
			if (lenghts_.contains(route)) {
				lenght += lenghts_.at(route);
			}
			else {
				lenght += lenghts_.at({ *next, *prey });
			}
		}
		if (false == is_roundtrip) {
			for (auto prey = stops.rbegin(), next = std::next(prey, 1), end = stops.rend();
				next != end; ++prey, ++next) {
				std::pair<const Stop*, const Stop*> route{ *prey, *next };
				if (lenghts_.contains(route)) {
					lenght += lenghts_.at(route);
				}
				else {
					lenght += lenghts_.at({ *next, *prey });
				}
			}
			distance += distance;
		}

		return { { static_cast<int>(count_stops),
			static_cast<int>(unique_stops.size()), lenght, lenght / distance } };
	}
	else
		return { std::nullopt };
}
const std::optional<domain::InfoStop> TransportCatalogue::GetStopInfo(const std::string_view stop) const {
	if (stops_buses.contains(stop)) {
		return { stops_buses.at(stop) };
	}
	else
		return { std::nullopt };
}

const std::deque<domain::Bus>& TransportCatalogue::GetBusesList() const {
	return buses_;
}
const std::deque<domain::Stop>& TransportCatalogue::GetStopsList() const {
	return stops_;
}