#include "svg.h"

namespace svg {

    using namespace std::literals;

    std::ostream& operator<< (std::ostream& out, const Color& color) {
        std::visit(CreateColor{ out }, color);
        return out;
    }

    void Object::Render(const RenderContext& context) const {
        context.RenderIndent();

        // Делегируем вывод тега своим подклассам
        RenderObject(context);

        context.out << std::endl;
    }

    // ---------- Circle ------------------

    Circle& Circle::SetCenter(Point center) {
        center_ = center;
        return *this;
    }

    Circle& Circle::SetRadius(double radius) {
        radius_ = radius;
        return *this;
    }

    void Circle::RenderObject(const RenderContext& context) const {
        auto& out = context.out;
        out << "<circle cx=\""sv << center_.x << "\" cy=\""sv << center_.y << "\" "sv;
        out << "r=\""sv << radius_ << "\""sv;
        RenderAttrs(context.out);
        out << "/>"sv;
    }

    Polyline& Polyline::AddPoint(Point point) {
        points_.push_back(point);
        return *this;
    }

    void Polyline::RenderObject(const RenderContext& context) const {
        auto& out = context.out;
        out << "<polyline points=\""sv;
        if (points_.size()) {
            out << points_.front().x << "," << points_.front().y;
            for (auto point = std::next(points_.begin(), 1), end = points_.end();
                point != end; ++point) {
                out << " " << point->x << "," << point->y;
            }
        }
        out << "\"";
        RenderAttrs(context.out);
        out << "/>"sv;
    }

    Text& Text::SetPosition(Point pos) {
        Text::pos = pos;
        return *this;
    }

    Text& Text::SetOffset(Point offset) {
        Text::offset = offset;
        return *this;
    }

    Text& Text::SetFontSize(uint32_t size) {
        font_size = size;
        return *this;
    }

    Text& Text::SetFontFamily(std::string font_family) {
        Text::font_family = font_family;
        return *this;
    }

    Text& Text::SetFontWeight(std::string font_weight) {
        Text::font_weight = font_weight;
        return *this;
    }

    Text& Text::SetData(std::string data) {
        Text::data = data;
        return *this;
    }

    void Text::RenderObject(const RenderContext& context) const {
        auto& out = context.out;

        out << "<text";
        RenderAttrs(context.out);
        out << " x=\""sv << pos.x << "\" y=\""sv << pos.y
            << "\" dx=\"" << offset.x << "\" dy=\"" << offset.y
            << "\" font-size=\"" << font_size << "\"";
        if (false == font_family.empty())
            out << " font-family=\"" << font_family << "\"";
        if (false == font_weight.empty())
            out << " font-weight=\"" << font_weight << "\"";

        out << ">" << data << "</text>";
    }

    void Document::AddPtr(std::unique_ptr<Object>&& obj) {
        objects_.push_back(std::move(obj));
    }

    void Document::Render(std::ostream& out) const {
        RenderContext ctx{ out, 2, 2 };
        out << "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>"sv << std::endl;
        out << "<svg xmlns=\"http://www.w3.org/2000/svg\" version=\"1.1\">"sv << std::endl;
        for (const auto& obj : objects_) {
            obj->Render(ctx);
        }
        out << "</svg>"sv;
    }

    std::ostream& operator<< (std::ostream& out, StrokeLineCap cap) {
        switch (cap) {
        case(StrokeLineCap::BUTT):
            out << "butt"; break;
        case(StrokeLineCap::ROUND):
            out << "round"; break;
        case(StrokeLineCap::SQUARE):
            out << "square"; break;
        }
        return out;
    }

    std::ostream& operator<< (std::ostream& out, StrokeLineJoin join) {
        switch (join) {
        case(StrokeLineJoin::ARCS):
            out << "arcs"; break;
        case(StrokeLineJoin::BEVEL):
            out << "bevel"; break;
        case(StrokeLineJoin::MITER):
            out << "miter"; break;
        case(StrokeLineJoin::MITER_CLIP):
            out << "miter-clip"; break;
        case(StrokeLineJoin::ROUND):
            out << "round"; break;
        }
        return out;
    }

}  // namespace svg